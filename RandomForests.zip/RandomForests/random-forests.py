import numpy as np
import pandas as pd 
from sklearn import tree
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import confusion_matrix
from sklearn.metrics import accuracy_score
from sklearn.feature_selection import SelectKBest
from sklearn.feature_selection import chi2
import os

#read data from csv
readCSV=pd.read_csv('german_credit.csv')

#store training data into corresponding lists
acc_bal=readCSV['Account.Balance']
duration=readCSV['Duration.of.Credit..month.']
pay_stat=readCSV['Payment.Status.of.Previous.Credit']
purpose=readCSV['Purpose']
cred_amt=readCSV['Credit.Amount']
vss=readCSV['Value.Savings.Stocks']
len_curr_emp=readCSV['Length.of.current.employment']
inst_per_cent=readCSV['Instalment.per.cent']
sms=readCSV['Sex...Marital.Status']
gts=readCSV['Guarantors']
dur_in_curr=readCSV['Duration.in.Current.address']
mvaa=readCSV['Most.valuable.available.asset']
age=readCSV['Age..years.']
con_creds=readCSV['Concurrent.Credits']
type_apt=readCSV['Type.of.apartment']
num_creds=readCSV['No.of.Credits.at.this.Bank']
occ=readCSV['Occupation']
num_dep=readCSV['No.of.dependents']
telephone=readCSV['Telephone']
fore_worker=readCSV['Foreign.Worker']

#prediction variable
creditability=readCSV['Creditability']


#convert pandas data to numpy arrays
acc_bal=acc_bal.as_matrix()
duration=duration.as_matrix()
pay_stat=pay_stat.as_matrix()
purpose=purpose.as_matrix()
cred_amt=cred_amt.as_matrix()
vss=vss.as_matrix()
len_curr_emp=len_curr_emp.as_matrix()
inst_per_cent=inst_per_cent.as_matrix()
sms=sms.as_matrix()
gts=gts.as_matrix()
dur_in_curr=dur_in_curr.as_matrix()
mvaa=mvaa.as_matrix()
age=age.as_matrix()
con_creds=con_creds.as_matrix()
type_apt=type_apt.as_matrix()
num_creds=num_creds.as_matrix()
occ=occ.as_matrix()
num_dep=num_dep.as_matrix()
telephone=telephone.as_matrix()
fore_worker=fore_worker.as_matrix()

creditability=creditability.as_matrix()

x=np.c_[acc_bal,duration,pay_stat,purpose,cred_amt,vss,len_curr_emp,inst_per_cent,sms,gts,dur_in_curr,mvaa,age,con_creds,type_apt,num_creds,occ,num_dep,telephone,fore_worker]

#k=12 because after PCA test, the graph shows only 12 out of 20 features are actually relevant
X_new = SelectKBest(chi2, k=12).fit_transform(x,creditability)

#Random Forests classifier
rf=RandomForestClassifier(n_estimators=100)
rf.fit(X_new,creditability)

#load test data
testCSV=pd.read_csv('Test_50.csv')


#store data into corresponding lists
acc_bal=testCSV['Account.Balance']
duration=testCSV['Duration.of.Credit..month.']
pay_stat=testCSV['Payment.Status.of.Previous.Credit']
purpose=testCSV['Purpose']
cred_amt=testCSV['Credit.Amount']
vss=testCSV['Value.Savings.Stocks']
len_curr_emp=testCSV['Length.of.current.employment']
inst_per_cent=testCSV['Instalment.per.cent']
sms=testCSV['Sex...Marital.Status']
#gts=testCSV['Guarantors']
#dur_in_curr=testCSV['Duration.in.Current.address']
mvaa=testCSV['Most.valuable.available.asset']
age=testCSV['Age..years.']
con_creds=testCSV['Concurrent.Credits']

creditability=testCSV['Creditability']

#convert pandas data to numpy arrays
acc_bal=acc_bal.as_matrix()
duration=duration.as_matrix()
pay_stat=pay_stat.as_matrix()
purpose=purpose.as_matrix()
cred_amt=cred_amt.as_matrix()
vss=vss.as_matrix()
len_curr_emp=len_curr_emp.as_matrix()
inst_per_cent=inst_per_cent.as_matrix()
sms=sms.as_matrix()
#gts=gts.as_matrix()
#dur_in_curr=dur_in_curr.as_matrix()
mvaa=mvaa.as_matrix()
age=age.as_matrix()
con_creds=con_creds.as_matrix()

creditability=creditability.as_matrix()

x_test=np.c_[acc_bal,duration,pay_stat,purpose,cred_amt,vss,len_curr_emp,inst_per_cent,sms,mvaa,age,con_creds]

prediction=rf.predict(x_test)

print prediction

print confusion_matrix(creditability,prediction)
print accuracy_score(creditability,prediction)
